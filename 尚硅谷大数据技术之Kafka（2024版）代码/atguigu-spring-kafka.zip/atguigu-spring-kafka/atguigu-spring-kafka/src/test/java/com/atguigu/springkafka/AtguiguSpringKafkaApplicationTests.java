package com.atguigu.springkafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtguiguSpringKafkaApplicationTests {

    @Test
    void contextLoads() {
    }

}
