package com.atguigu.springkafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtguiguSpringKafkaApplication {

    public static void main(String[] args) {
        SpringApplication.run(AtguiguSpringKafkaApplication.class, args);
    }

}
